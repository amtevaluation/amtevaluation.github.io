Compile:

./compile.sh

Usage:

Prepare an estimated score (e.g. 008_EST.xml) and a groud-truth score (e.g. 008_GT.xml). Then use the following command:

./evaluate_XML_voicePlus.sh 008_GT 008_EST ER

The evaluation metrics will be output in ER.txt.
The output metrics are, from left to right

(1)  pitch error rate
(2)  missing note rate
(3)  extra note rate
(4)  onset time error rate
(5)  offset time error rate
(6)  mean of (1) to (5)
(7)  voice error rate
(8)  mean of (1) to (5) and (7)
(9)  voice precision
(10) voice recall
(11) voice F measure

References:

Please see the following papers for the definitionos of the metrics.

Eita Nakamura, Emmanouil Benetos, Kazuyoshi Yoshii, Simon Dixon,
Towards Complete Polyphonic Music Transcription: Integrating Multi-Pitch Detection and Rhythm Quantization. 
Proc. 43rd IEEE International Conference on Acoustics, Speech and Signal Processing (ICASSP), pp. 101-105, 2018.

Yuki Hiramatsu, Eita Nakamura, Kazuyoshi Yoshii,
Joint Estimation of Note Values and Voices for Audio-to-Score Piano Transcription
Proc. 22nd International Society for Music Information Retrieval Conference (ISMIR), 2021.

Contact:

For any inquiries, please contact
Eita Nakamura (eita.nakamura@gmail.com)
